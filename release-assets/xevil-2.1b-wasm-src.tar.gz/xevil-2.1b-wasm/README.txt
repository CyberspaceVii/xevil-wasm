XEvil 2.1 beta, WebAssembly port, as played at https://cyberspace7.org/
Complete Corresponding Source (GPLv2+).

  xevil-src/   upstream XEvil, unmodified (lvella/xevil @ a016022)
  xevil-web/   the port: Xlib-on-SDL2 shim, main loop, glue, build scripts
               (see xevil-web/COPYING-port.txt)

Build: cd xevil-web && ./build-wasm.sh
